import { useState, useEffect, useRef } from "react";

// ── DATA ──────────────────────────────────────────────────────────────────────
const DAILY_MESSAGES = [
  "You are exactly where you need to be. Trust the process.",
  "Every small step forward is still progress. Keep going.",
  "You've survived 100% of your hard days. Today is no different.",
  "Peace is not the absence of problems — it's the presence of purpose.",
  "You are enough. Right now, exactly as you are.",
  "The fact that you're here, trying, says everything.",
  "Growth doesn't always feel like growth. Be patient with yourself.",
  "Your feelings are valid. Your story matters. You belong here.",
  "One breath at a time. One moment at a time. You've got this.",
  "Something beautiful is still ahead of you. Keep the door open.",
  "Rest is not quitting. Rest is how you come back stronger.",
  "You don't have to have it all figured out today.",
  "Showing up is already an act of courage.",
  "Your consistency is quietly building something extraordinary.",
  "Be gentle with yourself today. You deserve that kindness.",
];

const MOOD_SOUNDTRACKS = {
  peaceful: { emoji: "🌊", mood: "Peaceful", song: "Weightless", artist: "Marconi Union", why: "Your words carry stillness. This song holds space for it." },
  grateful: { emoji: "☀️", mood: "Grateful", song: "Here Comes the Sun", artist: "The Beatles", why: "Gratitude radiates from your words. Let this match the feeling." },
  hopeful: { emoji: "🌱", mood: "Hopeful", song: "Dog Days Are Over", artist: "Florence + The Machine", why: "Something in your words is reaching forward. This song runs with it." },
  reflective: { emoji: "🕯️", mood: "Reflective", song: "The Night Will Always Win", artist: "Manchester Orchestra", why: "You're sitting with something real today. This song understands." },
  joyful: { emoji: "✨", mood: "Joyful", song: "Good as Hell", artist: "Lizzo", why: "Your energy today is contagious. This song is your soundtrack." },
  tired: { emoji: "🌙", mood: "Tired but trying", song: "In My Life", artist: "The Beatles", why: "Rest is allowed. This song wraps around you gently." },
  strong: { emoji: "🔥", mood: "Strong", song: "Unstoppable", artist: "Sia", why: "Your words carry fire today. This song honors that." },
  gentle: { emoji: "🌸", mood: "Gentle", song: "Bloom", artist: "The Paper Kites", why: "There's softness in what you wrote. Let this song breathe with you." },
};

const MOOD_KEYWORDS = {
  peaceful: ["calm", "peace", "quiet", "still", "serene", "breathe", "relax"],
  grateful: ["grateful", "thankful", "blessed", "appreciate", "gratitude", "thank"],
  hopeful: ["hope", "future", "forward", "better", "goal", "dream", "tomorrow", "improve"],
  joyful: ["happy", "joy", "excited", "amazing", "great", "wonderful", "love", "laugh"],
  tired: ["tired", "exhausted", "rest", "sleep", "drained", "hard", "difficult", "struggle"],
  strong: ["strong", "powerful", "proud", "achieve", "win", "success", "crush", "dominate"],
  gentle: ["gentle", "soft", "slow", "easy", "small", "little", "tender", "kind"],
  reflective: ["think", "wonder", "realize", "remember", "reflect", "question", "feel", "notice"],
};

const MOCK_FRIENDS = [
  { id: 1, name: "Maya R.", initials: "MR", streak: 14, color: "#f97316", lastSeen: "Today", candle: true },
  { id: 2, name: "Jordan T.", initials: "JT", streak: 7, color: "#eab308", lastSeen: "Today", candle: true },
  { id: 3, name: "Sam K.", initials: "SK", streak: 3, color: "#84cc16", lastSeen: "Yesterday", candle: false },
  { id: 4, name: "Alex M.", initials: "AM", streak: 21, color: "#06b6d4", lastSeen: "Today", candle: true },
  { id: 5, name: "Riley P.", initials: "RP", streak: 1, color: "#a855f7", lastSeen: "Today", candle: false },
];

const JOURNAL_PROMPTS = {
  morning: [
    "What are you grateful for today? What's your intention?",
    "What would make today feel meaningful?",
    "Name three things you're looking forward to.",
    "What does your heart need most this morning?",
    "Who or what are you carrying with you into today?",
  ],
  midday: [
    "What's going well so far? Name 1–3 wins, big or small.",
    "What surprised you this morning?",
    "One moment today that made you feel alive?",
    "What are you proud of so far today?",
    "What's one small thing you did for yourself today?",
  ],
  evening: [
    "How are you feeling? What's one thing you're releasing tonight?",
    "What did today teach you?",
    "What moment do you want to remember from today?",
    "What are you leaving at the door tonight?",
    "How did you grow today, even a little?",
  ],
};

const SECTIONS = [
  { id: "morning", emoji: "🌅", label: "Morning Reflection", time: "Start your day with intention", color: "#f59e0b", gradient: "linear-gradient(135deg,#fbbf24,#f97316)", bg: "rgba(251,191,36,0.1)", border: "rgba(251,191,36,0.3)" },
  { id: "midday", emoji: "☀️", label: "Midday Wins", time: "Celebrate progress", color: "#ea580c", gradient: "linear-gradient(135deg,#f97316,#dc2626)", bg: "rgba(234,88,12,0.08)", border: "rgba(234,88,12,0.25)" },
  { id: "evening", emoji: "🌙", label: "Evening Note", time: "Close the day gently", color: "#b45309", gradient: "linear-gradient(135deg,#d97706,#92400e)", bg: "rgba(180,83,9,0.08)", border: "rgba(180,83,9,0.22)" },
];

// ── HELPERS ───────────────────────────────────────────────────────────────────
function getDayKey() { return new Date().toISOString().split("T")[0]; }
function getDailyMsg() { return DAILY_MESSAGES[new Date().getDate() % DAILY_MESSAGES.length]; }
function getGreeting() {
  const h = new Date().getHours();
  return h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";
}
function getPrompt(sectionId) {
  const arr = JOURNAL_PROMPTS[sectionId];
  return arr[new Date().getDate() % arr.length];
}
function detectMood(text) {
  const lower = text.toLowerCase();
  for (const [mood, words] of Object.entries(MOOD_KEYWORDS)) {
    if (words.some(w => lower.includes(w))) return mood;
  }
  return "reflective";
}
function getStreak(entries) {
  let s = 0, d = new Date();
  while (true) {
    const k = d.toISOString().split("T")[0];
    if (!entries[k] || Object.keys(entries[k]).length === 0) break;
    s++; d.setDate(d.getDate() - 1);
  }
  return s;
}

// ── CANDLE COMPONENT ──────────────────────────────────────────────────────────
function Candle({ lit, size = 32 }) {
  return (
    <div style={{ position: "relative", width: size, height: size * 1.5, display: "flex", flexDirection: "column", alignItems: "center" }}>
      {lit && (
        <div style={{
          width: size * 0.35, height: size * 0.5,
          background: "radial-gradient(ellipse at 50% 80%, #fbbf24 0%, #f97316 40%, transparent 100%)",
          borderRadius: "50% 50% 20% 20%",
          animation: "flicker 1.8s ease-in-out infinite",
          filter: "blur(1px)",
          marginBottom: -4,
        }} />
      )}
      <div style={{
        width: size * 0.55, height: size,
        background: lit
          ? "linear-gradient(180deg,#fef3c7 0%,#fbbf24 40%,#f97316 100%)"
          : "linear-gradient(180deg,#e5e7eb 0%,#d1d5db 100%)",
        borderRadius: "3px 3px 6px 6px",
        boxShadow: lit ? "0 0 12px rgba(251,191,36,0.5)" : "none",
        transition: "all 0.5s ease",
      }} />
    </div>
  );
}

// ── MAIN APP ─────────────────────────────────────────────────────────────────
export default function FlowrApp() {
  const [entries, setEntries] = useState(() => {
    try { return JSON.parse(localStorage.getItem("flowr_entries_v2") || "{}"); } catch { return {}; }
  });
  const [isPro, setIsPro] = useState(() => localStorage.getItem("flowr_pro") === "true");
  const [activeTab, setActiveTab] = useState("journal");
  const [expandedSection, setExpandedSection] = useState(null);
  const [drafts, setDrafts] = useState({});
  const [savedFx, setSavedFx] = useState({});
  const [soundtrack, setSoundtrack] = useState(null);
  const [showPaywall, setShowPaywall] = useState(false);
  const [showAddFriend, setShowAddFriend] = useState(false);
  const [friendCode, setFriendCode] = useState("");
  const [candleSent, setCandleSent] = useState({});
  const [showSoundtrackFor, setShowSoundtrackFor] = useState(null);
  const [mounted, setMounted] = useState(false);
  const textRef = useRef({});

  const todayKey = getDayKey();
  const todayEntries = entries[todayKey] || {};
  const completedToday = SECTIONS.filter(s => todayEntries[s.id]).length;
  const streak = getStreak(entries);
  const totalEntries = Object.values(entries).reduce((a, d) => a + Object.keys(d).length, 0);

  useEffect(() => { setTimeout(() => setMounted(true), 100); }, []);

  function saveEntry(sectionId) {
    const text = drafts[sectionId] || "";
    if (!text.trim()) return;
    const updated = { ...entries, [todayKey]: { ...todayEntries, [sectionId]: { text, ts: Date.now() } } };
    setEntries(updated);
    localStorage.setItem("flowr_entries_v2", JSON.stringify(updated));
    setSavedFx(s => ({ ...s, [sectionId]: true }));
    // detect mood & set soundtrack
    const mood = detectMood(text);
    setSoundtrack(MOOD_SOUNDTRACKS[mood] || MOOD_SOUNDTRACKS.reflective);
    setShowSoundtrackFor(sectionId);
    setTimeout(() => { setSavedFx(s => ({ ...s, [sectionId]: false })); setExpandedSection(null); }, 1400);
  }

  function sendCandle(friendId) {
    setCandleSent(s => ({ ...s, [friendId]: true }));
  }

  function unlockPro() {
    setIsPro(true);
    localStorage.setItem("flowr_pro", "true");
    setShowPaywall(false);
  }

  const historyDays = Object.keys(entries).sort((a, b) => b.localeCompare(a));
  const freeEntriesToday = SECTIONS.filter(s => todayEntries[s.id]).length;

  return (
    <div style={{
      minHeight: "100vh", maxWidth: 430, margin: "0 auto",
      background: "linear-gradient(160deg,#fffbf0 0%,#fef3c7 50%,#fde8c0 100%)",
      fontFamily: "'Palatino Linotype','Book Antiqua',Palatino,serif",
      position: "relative", overflow: "hidden", paddingBottom: 88,
    }}>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;0,700;1,400;1,600&family=DM+Sans:wght@300;400;500;600&display=swap');
        @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
        @keyframes popIn { 0%{opacity:0;transform:scale(0.88)} 70%{transform:scale(1.04)} 100%{opacity:1;transform:scale(1)} }
        @keyframes flicker { 0%,100%{opacity:1;transform:scaleY(1) scaleX(1)} 25%{opacity:.9;transform:scaleY(1.05) scaleX(.97)} 75%{opacity:.95;transform:scaleY(.97) scaleX(1.03)} }
        @keyframes shimmer { 0%{background-position:200% center} 100%{background-position:-200% center} }
        @keyframes candleGlow { 0%,100%{box-shadow:0 0 16px rgba(251,191,36,0.5)} 50%{box-shadow:0 0 28px rgba(251,191,36,0.8)} }
        @keyframes slideDown { from{opacity:0;transform:translateY(-10px)} to{opacity:1;transform:translateY(0)} }
        * { box-sizing:border-box; }
        textarea { outline:none; }
        textarea::placeholder { color:#c9a86c; }
        ::-webkit-scrollbar { width:3px; }
        ::-webkit-scrollbar-thumb { background:rgba(180,130,60,0.25); border-radius:4px; }
        .tab-btn { transition: all 0.2s ease; }
        .tab-btn:active { transform: scale(0.92); }
        .save-btn:active { transform: scale(0.96); }
        .section-card { transition: all 0.3s cubic-bezier(0.34,1.56,0.64,1); }
        .section-card:active { transform: scale(0.98); }
      `}</style>

      {/* Ambient orbs */}
      <div style={{ position:"fixed", top:-100, right:-80, width:280, height:280, borderRadius:"50%", background:"radial-gradient(circle,rgba(251,191,36,0.18) 0%,transparent 70%)", pointerEvents:"none", zIndex:0 }} />
      <div style={{ position:"fixed", bottom:80, left:-120, width:320, height:320, borderRadius:"50%", background:"radial-gradient(circle,rgba(234,88,12,0.1) 0%,transparent 70%)", pointerEvents:"none", zIndex:0 }} />

      <div style={{ position:"relative", zIndex:1, padding:"0 18px" }}>

        {/* ══ JOURNAL TAB ══════════════════════════════════════════════════════ */}
        {activeTab === "journal" && (
          <div style={{ animation: mounted ? "fadeUp 0.5s ease" : "none" }}>

            {/* Header */}
            <div style={{ paddingTop:52, paddingBottom:4, display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
              <div>
                <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:11, letterSpacing:2.5, textTransform:"uppercase", color:"#b45309", fontWeight:600 }}>
                  {getGreeting()}
                </div>
                <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:42, fontWeight:700, color:"#78350f", lineHeight:1, marginTop:2, letterSpacing:-1 }}>
                  Flowr
                </div>
                <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:12, color:"#a16207", marginTop:3, fontStyle:"italic" }}>
                  {new Date().toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric"})}
                </div>
              </div>
              {/* Ring */}
              <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:3, paddingTop:8 }}>
                <svg width={56} height={56}>
                  <circle cx={28} cy={28} r={23} fill="none" stroke="rgba(251,191,36,0.2)" strokeWidth={4}/>
                  <circle cx={28} cy={28} r={23} fill="none" stroke={completedToday===3?"#22c55e":"#f59e0b"} strokeWidth={4}
                    strokeDasharray={`${(completedToday/3)*144.5} 144.5`} strokeLinecap="round" transform="rotate(-90 28 28)"
                    style={{transition:"stroke-dasharray 0.8s cubic-bezier(0.34,1.56,0.64,1)"}}/>
                  <text x={28} y={33} textAnchor="middle" fill="#92400e" fontSize={14} fontWeight="700" fontFamily="sans-serif">{completedToday}/3</text>
                </svg>
                <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:9, color:"#b45309", letterSpacing:1, textTransform:"uppercase" }}>
                  {streak > 0 ? `🔥 ${streak}d` : "today"}
                </div>
              </div>
            </div>

            {/* Daily message */}
            <div style={{
              background:"linear-gradient(135deg,#fbbf24 0%,#f97316 100%)",
              borderRadius:20, padding:"18px 20px", marginTop:16, marginBottom:20,
              boxShadow:"0 10px 36px rgba(251,127,36,0.3)",
              animation:"popIn 0.5s ease 0.2s both", position:"relative", overflow:"hidden",
            }}>
              <div style={{ position:"absolute", top:-24, right:-24, width:100, height:100, borderRadius:"50%", background:"rgba(255,255,255,0.1)" }}/>
              <div style={{ position:"absolute", bottom:-32, left:8, width:72, height:72, borderRadius:"50%", background:"rgba(255,255,255,0.07)" }}/>
              <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:10, color:"rgba(255,255,255,0.8)", letterSpacing:2, textTransform:"uppercase", fontWeight:600, marginBottom:7 }}>✦ Today's Message</div>
              <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:17, color:"#fff", lineHeight:1.55, fontStyle:"italic" }}>
                "{getDailyMsg()}"
              </div>
            </div>

            {/* Soundtrack reveal */}
            {soundtrack && showSoundtrackFor && (
              <div style={{
                background:"linear-gradient(135deg,rgba(109,40,217,0.12),rgba(180,83,9,0.1))",
                border:"1.5px solid rgba(109,40,217,0.2)", borderRadius:18, padding:"14px 18px",
                marginBottom:18, animation:"slideDown 0.4s ease",
                backdropFilter:"blur(12px)",
              }}>
                <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:10, letterSpacing:2, textTransform:"uppercase", color:"#7c3aed", fontWeight:700, marginBottom:8 }}>🎵 Your Mood Soundtrack</div>
                <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                  <div style={{ width:46, height:46, borderRadius:12, background:"linear-gradient(135deg,#7c3aed,#db2777)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:22, flexShrink:0 }}>
                    {soundtrack.emoji}
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:17, fontWeight:700, color:"#78350f" }}>{soundtrack.song}</div>
                    <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:12, color:"#a16207" }}>{soundtrack.artist}</div>
                  </div>
                  <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:10, color:"#7c3aed", fontWeight:600 }}>{soundtrack.mood}</div>
                </div>
                <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:13.5, color:"#92400e", fontStyle:"italic", marginTop:10, lineHeight:1.5, borderTop:"1px solid rgba(109,40,217,0.1)", paddingTop:10 }}>
                  {soundtrack.why}
                </div>
                <button onClick={() => { setSoundtrack(null); setShowSoundtrackFor(null); }} style={{ background:"none", border:"none", fontSize:11, color:"#b45309", cursor:"pointer", marginTop:6, fontFamily:"'DM Sans',sans-serif", opacity:0.7 }}>dismiss</button>
              </div>
            )}

            {/* Journal sections */}
            {SECTIONS.map((section, i) => {
              const isExpanded = expandedSection === section.id;
              const entry = todayEntries[section.id];
              const isDone = !!entry;
              const isSaved = savedFx[section.id];
              const lockedForFree = !isPro && freeEntriesToday >= 3 && !isDone;

              return (
                <div key={section.id} className="section-card" style={{
                  marginBottom:14,
                  animation:`fadeUp 0.5s ease ${0.1+i*0.1}s both`,
                }}>
                  <div
                    onClick={() => {
                      if (isDone) return;
                      if (lockedForFree) { setShowPaywall(true); return; }
                      setExpandedSection(isExpanded ? null : section.id);
                    }}
                    style={{
                      background: isDone ? section.bg : "rgba(255,255,255,0.68)",
                      border:`1.5px solid ${isDone ? section.border : "rgba(251,191,36,0.2)"}`,
                      borderRadius:18, padding: isExpanded ? "18px 18px 16px" : "16px 18px",
                      cursor: isDone ? "default" : "pointer",
                      backdropFilter:"blur(10px)",
                      boxShadow: isExpanded ? "0 10px 32px rgba(180,100,9,0.14)" : "0 2px 10px rgba(180,100,9,0.06)",
                    }}
                  >
                    <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                      <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                        <div style={{
                          width:46, height:46, borderRadius:14,
                          background: isDone ? section.gradient : "rgba(251,191,36,0.12)",
                          display:"flex", alignItems:"center", justifyContent:"center",
                          fontSize:22, transition:"all 0.4s ease",
                          boxShadow: isDone ? `0 4px 16px ${section.color}55` : "none",
                        }}>
                          {isDone ? "✓" : section.emoji}
                        </div>
                        <div>
                          <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:17, fontWeight:700, color:"#78350f" }}>{section.label}</div>
                          <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:11, color:"#a16207", marginTop:1 }}>{section.time}</div>
                        </div>
                      </div>
                      {!isDone && !lockedForFree && (
                        <div style={{ fontSize:20, color:"#d97706", transform: isExpanded ? "rotate(90deg)" : "rotate(0deg)", transition:"transform 0.3s ease" }}>›</div>
                      )}
                      {isDone && <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:10, color:section.color, fontWeight:700, letterSpacing:1 }}>DONE ✦</div>}
                      {lockedForFree && <div style={{ fontSize:16 }}>🔒</div>}
                    </div>

                    {/* Expanded */}
                    {isExpanded && !isDone && (
                      <div style={{ marginTop:16, animation:"fadeUp 0.3s ease" }}>
                        <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:14.5, color:"#92400e", fontStyle:"italic", marginBottom:12, lineHeight:1.5 }}>
                          {getPrompt(section.id)}
                        </div>
                        <textarea
                          autoFocus
                          value={drafts[section.id] || ""}
                          onChange={e => setDrafts(d => ({ ...d, [section.id]: e.target.value }))}
                          placeholder="Write freely…"
                          rows={5}
                          style={{
                            width:"100%", border:"none", borderBottom:`2px solid ${section.border}`,
                            background:"transparent", fontSize:15, color:"#78350f",
                            resize:"none", padding:"6px 0", lineHeight:1.65,
                            fontFamily:"'Cormorant Garamond',serif",
                          }}
                        />
                        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginTop:12 }}>
                          <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:11, color:"#b45309", opacity:0.6 }}>
                            🎵 mood detected on save
                          </div>
                          <button className="save-btn" onClick={e => { e.stopPropagation(); saveEntry(section.id); }} style={{
                            background: isSaved ? "linear-gradient(135deg,#22c55e,#16a34a)" : section.gradient,
                            color:"#fff", border:"none", borderRadius:12,
                            padding:"10px 24px", fontSize:13, fontWeight:700,
                            cursor:"pointer", fontFamily:"'DM Sans',sans-serif", letterSpacing:0.5,
                            boxShadow:"0 4px 16px rgba(180,80,9,0.25)", transition:"all 0.3s ease",
                          }}>
                            {isSaved ? "✓ Saved!" : "Save & Detect Mood"}
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Saved preview */}
                    {isDone && entry?.text && (
                      <div style={{ marginTop:10, fontSize:14, color:"#92400e", fontStyle:"italic", lineHeight:1.6, paddingTop:10, borderTop:`1px solid ${section.border}`, fontFamily:"'Cormorant Garamond',serif" }}>
                        "{entry.text.length > 120 ? entry.text.slice(0,120)+"…" : entry.text}"
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Pro extra entries */}
            {isPro && completedToday === 3 && (
              <div style={{ animation:"fadeUp 0.4s ease" }}>
                <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:11, letterSpacing:2, textTransform:"uppercase", color:"#b45309", opacity:0.7, textAlign:"center", margin:"10px 0 12px" }}>✦ Unlimited Entries</div>
                <div
                  onClick={() => setExpandedSection(expandedSection === "extra" ? null : "extra")}
                  style={{
                    background:"rgba(255,255,255,0.55)", border:"1.5px dashed rgba(251,191,36,0.35)",
                    borderRadius:18, padding:"14px 18px", cursor:"pointer",
                    display:"flex", alignItems:"center", gap:12,
                  }}
                >
                  <div style={{ width:46, height:46, borderRadius:14, background:"rgba(251,191,36,0.12)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:22 }}>✍️</div>
                  <div>
                    <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:16, fontWeight:700, color:"#78350f" }}>Add another entry</div>
                    <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:11, color:"#a16207" }}>Write anytime, as often as you need</div>
                  </div>
                </div>
                {expandedSection === "extra" && (
                  <div style={{ background:"rgba(255,255,255,0.68)", borderRadius:18, padding:"18px", marginTop:10, border:"1px solid rgba(251,191,36,0.2)", animation:"fadeUp 0.3s ease" }}>
                    <textarea
                      autoFocus
                      value={drafts["extra"] || ""}
                      onChange={e => setDrafts(d => ({ ...d, extra: e.target.value }))}
                      placeholder="Whatever's on your mind…"
                      rows={5}
                      style={{ width:"100%", border:"none", borderBottom:"2px solid rgba(251,191,36,0.3)", background:"transparent", fontSize:15, color:"#78350f", resize:"none", padding:"6px 0", lineHeight:1.65, fontFamily:"'Cormorant Garamond',serif" }}
                    />
                    <button style={{ marginTop:12, background:"linear-gradient(135deg,#fbbf24,#f97316)", color:"#fff", border:"none", borderRadius:12, padding:"10px 24px", fontSize:13, fontWeight:700, cursor:"pointer", fontFamily:"'DM Sans',sans-serif", float:"right" }}>
                      Save & Detect Mood
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ══ FRIENDS TAB ══════════════════════════════════════════════════════ */}
        {activeTab === "friends" && (
          <div style={{ paddingTop:52, animation:"fadeUp 0.4s ease" }}>
            <div style={{ marginBottom:6 }}>
              <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:32, fontWeight:700, color:"#78350f" }}>Circle</div>
              <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:12, color:"#a16207", fontStyle:"italic" }}>Silent support. No words needed.</div>
            </div>

            {/* How it works */}
            <div style={{ background:"rgba(255,255,255,0.55)", borderRadius:16, padding:"14px 18px", marginBottom:20, marginTop:14, border:"1px solid rgba(251,191,36,0.18)" }}>
              <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:10, letterSpacing:2, textTransform:"uppercase", color:"#b45309", fontWeight:700, marginBottom:8 }}>How it works</div>
              <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:14.5, color:"#78350f", lineHeight:1.6 }}>
                When a friend journals, their candle glows. No messages. No pressure. Just the quiet knowing that someone is showing up for themselves — and you are too. Light their candle to say <em>"I see you."</em>
              </div>
            </div>

            {/* Your streak card */}
            <div style={{
              background:"linear-gradient(135deg,#fbbf24,#f97316)", borderRadius:18, padding:"16px 20px",
              marginBottom:20, boxShadow:"0 8px 28px rgba(251,127,36,0.28)", position:"relative", overflow:"hidden",
            }}>
              <div style={{ position:"absolute", top:-20, right:-20, width:80, height:80, borderRadius:"50%", background:"rgba(255,255,255,0.1)" }}/>
              <div style={{ display:"flex", alignItems:"center", gap:16 }}>
                <Candle lit={completedToday > 0} size={36} />
                <div>
                  <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:10, color:"rgba(255,255,255,0.8)", letterSpacing:2, textTransform:"uppercase", fontWeight:700 }}>Your candle</div>
                  <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:20, fontWeight:700, color:"#fff", marginTop:2 }}>
                    {completedToday > 0 ? "Glowing today ✦" : "Write to light it"}
                  </div>
                  <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:12, color:"rgba(255,255,255,0.85)", marginTop:1 }}>
                    🔥 {streak} day streak
                  </div>
                </div>
              </div>
            </div>

            {/* Friends list */}
            {MOCK_FRIENDS.map((friend, i) => (
              <div key={friend.id} style={{
                background:"rgba(255,255,255,0.65)", borderRadius:18, padding:"14px 18px",
                marginBottom:12, border:"1px solid rgba(251,191,36,0.15)",
                display:"flex", alignItems:"center", gap:14,
                animation:`fadeUp 0.4s ease ${i*0.07}s both`,
                backdropFilter:"blur(10px)",
              }}>
                {/* Avatar */}
                <div style={{
                  width:46, height:46, borderRadius:"50%",
                  background:`linear-gradient(135deg,${friend.color},${friend.color}88)`,
                  display:"flex", alignItems:"center", justifyContent:"center",
                  fontFamily:"'DM Sans',sans-serif", fontSize:14, fontWeight:700, color:"#fff", flexShrink:0,
                  boxShadow: friend.candle ? `0 0 16px ${friend.color}55, 0 0 6px ${friend.color}44` : "none",
                  animation: friend.candle ? "candleGlow 2s ease-in-out infinite" : "none",
                }}>
                  {friend.initials}
                </div>
                {/* Info */}
                <div style={{ flex:1 }}>
                  <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:17, fontWeight:700, color:"#78350f" }}>{friend.name}</div>
                  <div style={{ display:"flex", alignItems:"center", gap:8, marginTop:2 }}>
                    <Candle lit={friend.candle} size={16} />
                    <span style={{ fontFamily:"'DM Sans',sans-serif", fontSize:11, color: friend.candle ? "#f97316" : "#9ca3af" }}>
                      {friend.candle ? "Journaling today" : "Not yet today"}
                    </span>
                  </div>
                  <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:11, color:"#b45309", marginTop:2 }}>
                    🔥 {friend.streak} day streak
                  </div>
                </div>
                {/* Light candle btn */}
                <button
                  onClick={() => sendCandle(friend.id)}
                  style={{
                    background: candleSent[friend.id]
                      ? "linear-gradient(135deg,#22c55e,#16a34a)"
                      : friend.candle
                        ? "linear-gradient(135deg,#fbbf24,#f97316)"
                        : "rgba(251,191,36,0.12)",
                    border: friend.candle ? "none" : "1.5px solid rgba(251,191,36,0.25)",
                    borderRadius:12, padding:"8px 14px",
                    fontFamily:"'DM Sans',sans-serif", fontSize:12, fontWeight:700,
                    color: candleSent[friend.id] ? "#fff" : friend.candle ? "#fff" : "#b45309",
                    cursor:"pointer", transition:"all 0.3s ease", flexShrink:0,
                    boxShadow: friend.candle && !candleSent[friend.id] ? "0 4px 14px rgba(251,127,36,0.3)" : "none",
                  }}
                >
                  {candleSent[friend.id] ? "✓ Sent" : "🕯️ Light"}
                </button>
              </div>
            ))}

            {/* Add friend */}
            <button
              onClick={() => setShowAddFriend(!showAddFriend)}
              style={{
                width:"100%", background:"rgba(255,255,255,0.55)", border:"1.5px dashed rgba(251,191,36,0.35)",
                borderRadius:18, padding:"14px 18px", cursor:"pointer",
                fontFamily:"'Cormorant Garamond',serif", fontSize:16, color:"#b45309",
                marginBottom:16, transition:"all 0.2s ease",
              }}
            >
              + Add a friend to your Circle
            </button>
            {showAddFriend && (
              <div style={{ background:"rgba(255,255,255,0.68)", borderRadius:18, padding:"18px", border:"1px solid rgba(251,191,36,0.2)", animation:"slideDown 0.3s ease", marginBottom:16 }}>
                <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:15, color:"#78350f", marginBottom:10 }}>Enter your friend's Flowr code:</div>
                <input
                  value={friendCode}
                  onChange={e => setFriendCode(e.target.value)}
                  placeholder="e.g. FLOWR-2847"
                  style={{ width:"100%", border:"none", borderBottom:"2px solid rgba(251,191,36,0.35)", background:"transparent", fontSize:16, color:"#78350f", padding:"6px 0", fontFamily:"'Cormorant Garamond',serif", outline:"none" }}
                />
                <div style={{ display:"flex", gap:10, marginTop:14 }}>
                  <button style={{ flex:1, background:"linear-gradient(135deg,#fbbf24,#f97316)", color:"#fff", border:"none", borderRadius:12, padding:"10px", fontSize:13, fontWeight:700, cursor:"pointer", fontFamily:"'DM Sans',sans-serif" }}>Connect</button>
                  <button onClick={() => setShowAddFriend(false)} style={{ background:"none", border:"1px solid rgba(251,191,36,0.3)", borderRadius:12, padding:"10px 16px", fontSize:13, color:"#b45309", cursor:"pointer", fontFamily:"'DM Sans',sans-serif" }}>Cancel</button>
                </div>
                <div style={{ marginTop:12, fontFamily:"'DM Sans',sans-serif", fontSize:11, color:"#b45309", textAlign:"center", opacity:0.7 }}>
                  Your code: <strong>FLOWR-{Math.floor(Math.random()*9000+1000)}</strong>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══ HISTORY TAB ══════════════════════════════════════════════════════ */}
        {activeTab === "history" && (
          <div style={{ paddingTop:52, animation:"fadeUp 0.4s ease" }}>
            <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:32, fontWeight:700, color:"#78350f", marginBottom:4 }}>Your Journey</div>
            <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:12, color:"#a16207", fontStyle:"italic", marginBottom:20 }}>Every entry is a step forward</div>

            {historyDays.length === 0 ? (
              <div style={{ textAlign:"center", padding:"60px 20px", color:"#b45309" }}>
                <div style={{ fontSize:36, marginBottom:12 }}>🌱</div>
                <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:18, fontStyle:"italic" }}>Your story starts today.</div>
                <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:13, opacity:0.6, marginTop:6 }}>Complete your first entry to see it here.</div>
              </div>
            ) : historyDays.map((day, i) => {
              const dayData = entries[day];
              const date = new Date(day + "T12:00:00");
              const label = date.toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric"});
              const count = SECTIONS.filter(s => dayData[s.id]).length;
              return (
                <div key={day} style={{
                  background:"rgba(255,255,255,0.65)", borderRadius:18, padding:"16px 18px",
                  marginBottom:14, border:"1px solid rgba(251,191,36,0.18)",
                  animation:`fadeUp 0.4s ease ${i*0.06}s both`, backdropFilter:"blur(10px)",
                }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
                    <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:16, fontWeight:700, color:"#78350f" }}>{label}</div>
                    <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:10, color:"#b45309", fontWeight:700, letterSpacing:1 }}>{count}/3</div>
                  </div>
                  {SECTIONS.filter(s => dayData[s.id]).map((s,j) => (
                    <div key={s.id} style={{ marginBottom: j < SECTIONS.filter(x=>dayData[x.id]).length-1 ? 10 : 0, paddingBottom: j < SECTIONS.filter(x=>dayData[x.id]).length-1 ? 10 : 0, borderBottom: j < SECTIONS.filter(x=>dayData[x.id]).length-1 ? "1px solid rgba(251,191,36,0.12)" : "none" }}>
                      <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:10, color:s.color, fontWeight:700, letterSpacing:1, marginBottom:4 }}>{s.emoji} {s.label.toUpperCase()}</div>
                      <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:14, color:"#92400e", fontStyle:"italic", lineHeight:1.55 }}>
                        "{dayData[s.id]?.text?.length > 100 ? dayData[s.id].text.slice(0,100)+"…" : dayData[s.id]?.text}"
                      </div>
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        )}

        {/* ══ PROFILE TAB ══════════════════════════════════════════════════════ */}
        {activeTab === "profile" && (
          <div style={{ paddingTop:52, animation:"fadeUp 0.4s ease" }}>
            {/* Avatar */}
            <div style={{ textAlign:"center", marginBottom:24 }}>
              <div style={{
                width:88, height:88, borderRadius:"50%", margin:"0 auto 14px",
                background:"linear-gradient(135deg,#fbbf24,#f97316)",
                display:"flex", alignItems:"center", justifyContent:"center",
                fontSize:38, boxShadow:"0 10px 32px rgba(251,127,36,0.32)",
              }}>🌸</div>
              <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:28, fontWeight:700, color:"#78350f" }}>Your Profile</div>
              {isPro && <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:11, color:"#f97316", fontWeight:700, letterSpacing:1.5, textTransform:"uppercase", marginTop:4 }}>✦ Flowr Pro</div>}
            </div>

            {/* Stats */}
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:10, marginBottom:20 }}>
              {[
                { label:"Days", value:Object.keys(entries).length, icon:"📅" },
                { label:"Entries", value:totalEntries, icon:"✍️" },
                { label:"Streak", value:`${streak}🔥`, icon:"" },
              ].map(stat => (
                <div key={stat.label} style={{ background:"rgba(255,255,255,0.65)", borderRadius:16, padding:"16px 10px", textAlign:"center", border:"1px solid rgba(251,191,36,0.18)", backdropFilter:"blur(8px)" }}>
                  <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:26, fontWeight:700, color:"#78350f" }}>{stat.value}</div>
                  <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:10, color:"#a16207", marginTop:2, letterSpacing:0.5 }}>{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Pro card */}
            {!isPro ? (
              <div style={{
                background:"linear-gradient(135deg,#fbbf24 0%,#f97316 100%)",
                borderRadius:20, padding:"22px 22px", marginBottom:16,
                boxShadow:"0 10px 32px rgba(251,127,36,0.32)", position:"relative", overflow:"hidden",
              }}>
                <div style={{ position:"absolute", top:-24, right:-24, width:100, height:100, borderRadius:"50%", background:"rgba(255,255,255,0.1)" }}/>
                <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:10, color:"rgba(255,255,255,0.85)", letterSpacing:2, textTransform:"uppercase", fontWeight:700, marginBottom:8 }}>✦ FLOWR PRO</div>
                <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:28, fontWeight:700, color:"#fff", marginBottom:4 }}>$1.99 <span style={{fontSize:15, fontWeight:400}}>/month</span></div>
                <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:13, color:"rgba(255,255,255,0.9)", marginBottom:16, lineHeight:1.55 }}>
                  ✦ Unlimited journal entries<br/>
                  🎵 Daily mood soundtrack<br/>
                  🕯️ Silent Circle (friend streaks)<br/>
                  ✦ Rotating daily messages<br/>
                  📖 Full history forever
                </div>
                <button onClick={() => setShowPaywall(true)} style={{
                  background:"#fff", color:"#ea580c", border:"none", borderRadius:12,
                  padding:"12px 28px", fontSize:14, fontWeight:700, cursor:"pointer",
                  fontFamily:"'DM Sans',sans-serif", letterSpacing:0.5, boxShadow:"0 4px 14px rgba(0,0,0,0.12)",
                }}>
                  Start Free Trial
                </button>
              </div>
            ) : (
              <div style={{ background:"linear-gradient(135deg,#fbbf24,#f97316)", borderRadius:20, padding:"20px 22px", marginBottom:16, boxShadow:"0 8px 28px rgba(251,127,36,0.28)" }}>
                <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:10, color:"rgba(255,255,255,0.85)", letterSpacing:2, textTransform:"uppercase", fontWeight:700, marginBottom:6 }}>✦ PRO ACTIVE</div>
                <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:20, color:"#fff", fontStyle:"italic" }}>Thank you for being part of Flowr. You're growing. 🌊</div>
              </div>
            )}

            <div style={{ background:"rgba(255,255,255,0.55)", borderRadius:16, padding:"18px", border:"1px solid rgba(251,191,36,0.18)", textAlign:"center" }}>
              <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:15, color:"#92400e", fontStyle:"italic", lineHeight:1.7 }}>
                "Flowr was built for moments of stillness.<br/>Keep showing up for yourself."
              </div>
              <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:11, color:"#b45309", marginTop:8, opacity:0.6 }}>
                Your code: <strong>FLOWR-{typeof window !== "undefined" ? (parseInt(localStorage.getItem("flowr_code") || 0) || (() => { const c = Math.floor(Math.random()*9000+1000); localStorage.setItem("flowr_code",c); return c; })()) : "----"}</strong>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* ══ BOTTOM NAV ═══════════════════════════════════════════════════════════ */}
      <div style={{
        position:"fixed", bottom:0, left:"50%", transform:"translateX(-50%)",
        width:"100%", maxWidth:430,
        background:"rgba(255,249,235,0.94)", backdropFilter:"blur(20px)",
        borderTop:"1px solid rgba(251,191,36,0.18)",
        display:"flex", justifyContent:"space-around", alignItems:"center",
        padding:"10px 0 22px", zIndex:100,
      }}>
        {[
          { id:"journal", icon:"🌊", label:"Journal" },
          { id:"friends", icon:"🕯️", label:"Circle" },
          { id:"history", icon:"📖", label:"History" },
          { id:"profile", icon:"🌸", label:"Profile" },
        ].map(tab => (
          <button key={tab.id} className="tab-btn" onClick={() => setActiveTab(tab.id)} style={{
            background:"none", border:"none", cursor:"pointer",
            display:"flex", flexDirection:"column", alignItems:"center", gap:3,
            padding:"4px 16px",
          }}>
            <span style={{ fontSize:22 }}>{tab.icon}</span>
            <span style={{
              fontFamily:"'DM Sans',sans-serif", fontSize:9.5, fontWeight:700, letterSpacing:1,
              color: activeTab === tab.id ? "#ea580c" : "#b45309",
              transition:"color 0.2s ease",
              textTransform:"uppercase",
            }}>{tab.label}</span>
            {activeTab === tab.id && <div style={{ width:4, height:4, borderRadius:"50%", background:"#ea580c" }}/>}
          </button>
        ))}
      </div>

      {/* ══ PAYWALL MODAL ════════════════════════════════════════════════════════ */}
      {showPaywall && (
        <div style={{
          position:"fixed", inset:0, background:"rgba(0,0,0,0.55)", zIndex:200,
          display:"flex", alignItems:"flex-end", justifyContent:"center",
          backdropFilter:"blur(4px)",
        }} onClick={() => setShowPaywall(false)}>
          <div onClick={e => e.stopPropagation()} style={{
            background:"linear-gradient(170deg,#fffbf0,#fef3c7)", borderRadius:"28px 28px 0 0",
            padding:"28px 24px 40px", width:"100%", maxWidth:430,
            animation:"fadeUp 0.4s cubic-bezier(0.34,1.56,0.64,1)",
            boxShadow:"0 -20px 60px rgba(0,0,0,0.2)",
          }}>
            <div style={{ textAlign:"center", marginBottom:24 }}>
              <div style={{ fontSize:44, marginBottom:10 }}>🌊</div>
              <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:30, fontWeight:700, color:"#78350f" }}>Flowr Pro</div>
              <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:13, color:"#a16207", marginTop:4 }}>Everything you need. Nothing you don't.</div>
            </div>
            {[
              ["✦", "Unlimited journal entries, anytime"],
              ["🎵", "Daily mood soundtrack after every entry"],
              ["🕯️", "Silent Circle — see friends' streaks glow"],
              ["💬", "Rotating daily affirmation messages"],
              ["📖", "Full history, forever"],
            ].map(([icon, text]) => (
              <div key={text} style={{ display:"flex", alignItems:"center", gap:14, marginBottom:14 }}>
                <div style={{ width:36, height:36, borderRadius:10, background:"rgba(251,191,36,0.15)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:18, flexShrink:0 }}>{icon}</div>
                <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:14, color:"#78350f" }}>{text}</div>
              </div>
            ))}
            <div style={{ margin:"22px 0 16px" }}>
              <button onClick={unlockPro} style={{
                width:"100%", background:"linear-gradient(135deg,#fbbf24,#f97316)",
                color:"#fff", border:"none", borderRadius:16, padding:"16px",
                fontSize:16, fontWeight:700, cursor:"pointer",
                fontFamily:"'DM Sans',sans-serif", letterSpacing:0.5,
                boxShadow:"0 8px 28px rgba(251,127,36,0.35)",
              }}>
                Start Free Trial · $1.99/mo
              </button>
              <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:11, color:"#b45309", textAlign:"center", marginTop:10, opacity:0.7 }}>
                Cancel anytime · No commitment
              </div>
            </div>
            <button onClick={() => setShowPaywall(false)} style={{ width:"100%", background:"none", border:"none", color:"#b45309", fontSize:13, cursor:"pointer", fontFamily:"'DM Sans',sans-serif", opacity:0.6 }}>
              Maybe later
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
